import React from 'react'

export default class Mine extends React.Component{
  render(){
    return(
      <div class="mine">
        <h1>我是我的页</h1>
      </div>
    )
  }
}