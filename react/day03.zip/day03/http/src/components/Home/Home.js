import React from 'react'

export default class Home extends React.Component{

  render () {
    return (
        <div class="home">
          <h1>我是Home页</h1>
        </div>
      )
  }
}