import React from 'react'

export default class Cart extends React.Component{
  render(){
    return(
      <div class="cart">
        <h1>我是购物车</h1>
      </div>
    )
  }
}